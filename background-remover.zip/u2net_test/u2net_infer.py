import cv2
import torch
import numpy as np
from PIL import Image
from torchvision import transforms
from u2net_test.model import U2NET

model_path = 'u2net/u2net.pth'
net = U2NET(3, 1)
net.load_state_dict(torch.load(model_path, map_location='cpu'))
net.eval()

def remove(input_path, output_path):
    image = Image.open(input_path).convert("RGB")
    transform = transforms.Compose([
        transforms.Resize((320, 320)),
        transforms.ToTensor()
    ])
    input_tensor = transform(image).unsqueeze(0)
    with torch.no_grad():
        d1, *_ = net(input_tensor)
        mask = d1[0][0].cpu().numpy()
        mask = (mask - mask.min()) / (mask.max() - mask.min())
        mask = cv2.resize(mask, image.size)
        img = np.array(image)
        rgba = np.dstack((img, (mask * 255).astype(np.uint8)))
        Image.fromarray(rgba).save(output_path)