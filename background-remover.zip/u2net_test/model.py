import torch.nn as nn

# Simple U2NET-like dummy model for example
class U2NET(nn.Module):
    def __init__(self, in_ch, out_ch):
        super(U2NET, self).__init__()
        self.layer = nn.Sequential(
            nn.Conv2d(in_ch, 64, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.Conv2d(64, out_ch, kernel_size=3, padding=1),
            nn.Sigmoid()
        )
    def forward(self, x):
        return self.layer(x), None, None, None, None, None, None